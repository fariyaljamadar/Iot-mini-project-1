#pragma once

// ---------- Wi-Fi ----------
// "Wokwi-GUEST" (open network) is the built-in Wi-Fi of the Wokwi simulator.
// For real hardware, replace with your own network credentials.
#define WIFI_SSID     "Wokwi-GUEST"
#define WIFI_PASSWORD ""
#define WIFI_CHANNEL  6          // speeds up connection in Wokwi

// ---------- MQTT ----------
// Public broker: anyone can read these topics. Change the prefix to something
// unique (e.g. "wit-solapur/classroom/...") before sharing your setup.
#define MQTT_BROKER     "broker.hivemq.com"
#define MQTT_PORT       1883
#define MQTT_CLIENT_ID  "esp32-smart-classroom"
#define TOPIC_DATA      "classroom/data"
#define TOPIC_CONTROL   "classroom/control"

// ---------- Pins (ESP32 DevKit V1) ----------
#define PIN_PIR    27   // PIR OUT
#define PIN_DHT    15   // DHT22 SDA/DATA
#define PIN_LDR    34   // LDR analog out (ADC1, input only)
#define PIN_RELAY  26   // Relay IN  -> fan (appliance)
#define PIN_LED    25   // LED       -> light (via 220 ohm resistor)

#define RELAY_ACTIVE_LOW false

// ---------- Behaviour ----------
#define SAMPLE_INTERVAL_MS  2000    // sensor read + inference + publish period
#define MOTION_HOLD_MS      15000   // PIR is pulsed; keep "recent motion" for this long
#define LUX_THRESHOLD       500.0f  // light turns ON only if room is darker than this
#define OCCUPIED_THRESHOLD  0.5f    // model probability >= this -> OCCUPIED
