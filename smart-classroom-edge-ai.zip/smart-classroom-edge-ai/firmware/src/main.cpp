/*
 * IoT-Based Smart Classroom Occupancy & Energy Optimization System (Edge AI)
 * Walchand Institute of Technology, Solapur - Dept. of Electronics & Computer Engg.
 *
 * ESP32 reads PIR + DHT22 + LDR, runs a tiny logistic-regression occupancy model
 * locally (Edge AI), switches light/fan, and publishes JSON to MQTT for Node-RED.
 */
#include <Arduino.h>
#include <WiFi.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <DHT.h>
#include <math.h>

#include "config.h"
#include "model.h"

WiFiClient   wifiClient;
PubSubClient mqtt(wifiClient);
DHT          dht(PIN_DHT, DHT22);

// Latest sensor values (kept if a DHT read fails)
float temperature = 25.0f;
float humidity    = 50.0f;
float lux         = 0.0f;

// State
bool          light        = false;
bool          fan          = false;
bool          manualMode   = false;   // set from Node-RED via classroom/control
bool          manualLight  = false;
bool          manualFan    = false;
bool          everMotion   = false;
unsigned long lastMotionMs = 0;
unsigned long lastSampleMs = 0;

// ---------------------------------------------------------------- helpers
void writeOutput(uint8_t pin, bool on, bool activeLow) {
  digitalWrite(pin, (on != activeLow) ? HIGH : LOW);
}

void applyOutputs() {
  writeOutput(PIN_LED, light, false);
  writeOutput(PIN_RELAY, fan, RELAY_ACTIVE_LOW);
}

// Convert LDR ADC reading to lux (formula used by the Wokwi photoresistor model)
float readLux() {
  const float GAMMA = 0.7f;
  const float RL10  = 50.0f;   // kOhm at 10 lux
  int raw = analogRead(PIN_LDR);
  raw = constrain(raw, 1, 4094);
  float voltage    = raw / 4095.0f * 3.3f;
  float resistance = 2000.0f * voltage / (1.0f - voltage / 3.3f);
  float value      = powf(RL10 * 1e3f * powf(10.0f, GAMMA) / resistance, 1.0f / GAMMA);
  return constrain(value, 0.0f, 1000.0f);
}

// ---------------------------------------------------------------- Edge AI
// Logistic regression: p = sigmoid(w . standardise(x) + b)
float predictOccupancy(float motion, float t, float h, float l) {
  const float x[MODEL_N_FEATURES] = {motion, t, h, l};
  float z = MODEL_BIAS;
  for (int i = 0; i < MODEL_N_FEATURES; i++) {
    z += MODEL_WEIGHTS[i] * ((x[i] - MODEL_MEAN[i]) / MODEL_STD[i]);
  }
  return 1.0f / (1.0f + expf(-z));
}

// ---------------------------------------------------------------- MQTT
void onMessage(char *topic, byte *payload, unsigned int length) {
  StaticJsonDocument<192> doc;
  if (deserializeJson(doc, payload, length)) {
    Serial.println("[MQTT] Bad control JSON ignored");
    return;
  }
  const char *mode   = doc["mode"]   | "";
  const char *action = doc["action"] | "";

  if (strcmp(mode, "manual") == 0) {
    manualMode  = true;
    manualLight = doc["light"] | 0;
    manualFan   = doc["fan"]   | 0;
  } else if (strcmp(mode, "auto") == 0) {
    manualMode = false;
  }
  if (strcmp(action, "FORCE_OFF") == 0 && !manualMode) {
    light = false;
    fan   = false;
    applyOutputs();
  }
  Serial.printf("[MQTT] control: mode=%s action=%s\n", mode, action);
}

void connectWiFi() {
  Serial.print("Connecting to Wi-Fi");
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD, WIFI_CHANNEL);
  while (WiFi.status() != WL_CONNECTED) {
    delay(300);
    Serial.print(".");
  }
  Serial.println(" connected");
}

void connectMQTT() {
  while (!mqtt.connected()) {
    Serial.print("Connecting to MQTT...");
    if (mqtt.connect(MQTT_CLIENT_ID)) {
      Serial.println(" connected");
      mqtt.subscribe(TOPIC_CONTROL);
    } else {
      Serial.printf(" failed (rc=%d), retry in 2 s\n", mqtt.state());
      delay(2000);
    }
  }
}

// ---------------------------------------------------------------- setup/loop
void setup() {
  Serial.begin(115200);
  pinMode(PIN_PIR, INPUT);
  pinMode(PIN_LED, OUTPUT);
  pinMode(PIN_RELAY, OUTPUT);
  applyOutputs();
  dht.begin();

  connectWiFi();
  mqtt.setServer(MQTT_BROKER, MQTT_PORT);
  mqtt.setBufferSize(512);
  mqtt.setCallback(onMessage);
  connectMQTT();
}

void loop() {
  if (WiFi.status() != WL_CONNECTED) connectWiFi();
  if (!mqtt.connected()) connectMQTT();
  mqtt.loop();

  // PIR is read continuously so short pulses are not missed
  if (digitalRead(PIN_PIR) == HIGH) {
    lastMotionMs = millis();
    everMotion   = true;
  }

  if (millis() - lastSampleMs < SAMPLE_INTERVAL_MS) return;
  lastSampleMs = millis();

  // 1. Read sensors
  float t = dht.readTemperature();
  float h = dht.readHumidity();
  if (!isnan(t)) temperature = t;
  if (!isnan(h)) humidity    = h;
  lux = readLux();
  bool motionRecent = everMotion && (millis() - lastMotionMs < MOTION_HOLD_MS);

  // 2. Edge-AI inference
  float prob     = predictOccupancy(motionRecent ? 1.0f : 0.0f, temperature, humidity, lux);
  bool  occupied = prob >= OCCUPIED_THRESHOLD;
  float confidence = occupied ? prob : 1.0f - prob;

  // 3. Control logic
  if (manualMode) {
    light = manualLight;
    fan   = manualFan;
  } else if (occupied) {
    light = (lux < LUX_THRESHOLD);   // only if the room is dark enough
    fan   = true;
  } else {
    light = false;
    fan   = false;
  }
  applyOutputs();

  // 4. Serial monitor
  Serial.printf("PIR:%d | %s (conf %.0f%%) | T:%.1fC H:%.1f%% Lux:%.0f | Light:%s Fan:%s%s\n",
                motionRecent, occupied ? "OCCUPIED" : "EMPTY", confidence * 100.0f,
                temperature, humidity, lux, light ? "ON" : "OFF", fan ? "ON" : "OFF",
                manualMode ? " [MANUAL]" : "");

  // 5. Publish JSON to Node-RED
  StaticJsonDocument<256> doc;
  doc["people"]     = occupied ? 1 : 0;   // occupancy flag (1 = occupied)
  doc["temp"]       = round(temperature * 10.0f) / 10.0f;
  doc["hum"]        = round(humidity * 10.0f) / 10.0f;
  doc["lux"]        = (int)lux;
  doc["light"]      = light ? 1 : 0;
  doc["fan"]        = fan ? 1 : 0;
  doc["confidence"] = (int)(confidence * 100.0f);
  doc["mode"]       = manualMode ? "manual" : "auto";

  char buffer[256];
  serializeJson(doc, buffer);
  mqtt.publish(TOPIC_DATA, buffer);
}
